/*
** gen.h for gen in /home/efilon/Projects/Cproject/Tests/header_gen
** 
** Made by sebastien antonico
** Login   <antoni_s@epitech.eu>
** 
** Started on  Thu Apr 25 15:34:50 2013 sebastien antonico
** Last update Thu Apr 25 15:35:34 2013 sebastien antonico
*/

#ifndef GEN_H_
# define GEN_H_

#define SIZE_READ (16)                                                                                                                                                                                                                                                        

char    *get_next_line(const int fd);
int     match(char *s1, char *s2);


#endif /* !GEN_H_ */
